## Authors

List of authors who have contributed, sorted alphabetically:

- Johan B. C. Engelen
- Jaimie M. Jellema
- Frits P. Kuipers
