var searchData=
[
  ['setlives_40',['setLives',['../class_u_i.html#a95aad652d6420d2aadd0fa90022af750',1,'UI']]],
  ['setscore_41',['setScore',['../class_u_i.html#a6b628d22bffffb32e08e78afe556e02e',1,'UI']]]
];
