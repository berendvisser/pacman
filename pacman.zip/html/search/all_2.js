var searchData=
[
  ['dir_2',['dir',['../struct_game_object_struct.html#ab9915f159f6dc0f9a125cbd2841e39e4',1,'GameObjectStruct']]],
  ['direction_3',['Direction',['../_game_object_struct_8h.html#a224b9163917ac32fc95a60d8c1eec3aa',1,'GameObjectStruct.h']]]
];
