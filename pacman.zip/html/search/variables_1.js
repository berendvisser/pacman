var searchData=
[
  ['type_46',['type',['../struct_game_object_struct.html#ac3ad961fbfaa1a893d72aab24d090b8d',1,'GameObjectStruct']]]
];
