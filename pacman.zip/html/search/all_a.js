var searchData=
[
  ['type_18',['type',['../struct_game_object_struct.html#ac3ad961fbfaa1a893d72aab24d090b8d',1,'GameObjectStruct::type()'],['../_game_object_struct_8h.html#a1d1cfd8ffb84e947f82999c682b666a7',1,'Type():&#160;GameObjectStruct.h']]]
];
