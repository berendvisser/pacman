var searchData=
[
  ['license_52',['License',['../md__l_i_c_e_n_s_e.html',1,'']]]
];
