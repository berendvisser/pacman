var searchData=
[
  ['authors_0',['Authors',['../md__a_u_t_h_o_r_s.html',1,'']]]
];
